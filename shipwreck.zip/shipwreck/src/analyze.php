<!DOCTYPE html>
<html>
<head>
   <title>Shipwreck Analysis</title>
   <!-- Plotly.js & D3 -->
  <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/d3/4.12.2/d3.js"></script>
  <!-- Numeric JS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/numeric/1.2.6/numeric.min.js">   <script src="http://labratrevenge.com/d3-tip/javascripts/d3.tip.v0.6.3.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/alasql@0.4.2/dist/alasql.min.js"></script>
   <script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
   <script src="//code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
   <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">
   <script src="https://npmcdn.com/tether@1.2.4/dist/js/tether.min.js"></script>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
   <style type="text/css">
html,body {
      height: 100%;
      margin: 0;
      padding: 0;
      font-family: -apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
    }
    .navbargradient {
      background: #ffffff;
      /* Old browsers */
      background: -moz-linear-gradient(top, #ffffff 0%, #e5e5e5 100%);
      /* FF3.6-15 */
      background: -webkit-linear-gradient(top, #ffffff 0%, #e5e5e5 100%);
      /* Chrome10-25,Safari5.1-6 */
      background: linear-gradient(to bottom, #ffffff 0%, #e5e5e5 100%);
      /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
      filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ffffff', endColorstr='#e5e5e5', GradientType=0);
      /* IE6-9 */
    }

.svg-container, .main-svg {
  height: 525px !important;
}

</style>

</head>

<body class="animated fadeInRight">
<div>
    <nav class="navbar navbar-toggleable-md navbar-light bg-faded navbargradient">
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarToggle" aria-controls="navbarToggle" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
      <a class="navbar-brand" href="index.php" style="font-weight: bold">Modern Shipwrecks</a>
      <div class="collapse navbar-collapse" id="navbarToggle">
        <ul class="navbar-nav mr-auto mt-2 mt-md-0">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="data-download.php">Data</a>
          </li>
          <li class="nav-item">
	    <a class="nav-link" href="analyze.php">Analyze</a>
          </li>
          <li class="nav-item dropdown">
		        <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		          Resources
		        </a>
		        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
		          <a class="dropdown-item" href="pmsimages.php">Photos</a>
		          <a class="dropdown-item" href="pmsdocs.php">Documents</a>
		          <a class="dropdown-item" href="glossary.html">Ship Glossary</a>
		          <a class="dropdown-item" href="metadata.html">Data Dictionary</a>
		          <a class="dropdown-item" href="astrolabes.php">Astrolabes</a>
		        </div>
		      </li>
          <li class="nav-item">
            <a class="nav-link" href="about.html">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
        </ul>
      </div>
      <div>
        <a href="https://www.tamu.edu/"><img border="0" alt="TAMU" src="../images/Capture.png" width="200px"></a>
      </div>
    </nav>
</div>
<div id="graph"></div>
<br>
<div id="graph2"></div>
<br>
<div id="graph3"></div>
<script>

// ------------- Plot 1 -------------------------------------------------------------------------------
let xl = []
let yl = []
Plotly.d3.json('analyze_data/analyzeData_1.php', function(data){
 //console.log(data);
 data.forEach(function(d) {
        var keelValue = parseFloat(d.KeelLength);
        xl.push(d.Site);
        yl.push(keelValue);
 });

 let trace = {
   x: xl,
   y: yl,
   type: 'bar'
 }
 let layout = {
   title: 'Shipwreck Analysis',
   yaxis: {title: 'Keel Length [meters]'},
 }
Plotly.plot(document.getElementById('graph'), [trace], layout); });

// ------------- Plot 2 -------------------------------------------------------------------------------
let x2 = []
let y2 = []
Plotly.d3.json('analyze_data/analyzeData_2.php', function(data){
 //console.log(data);
 data.forEach(function(d) {
        const ShipwreckCount = parseInt(d.ShipwreckCount);
        x2.push(d.LostCountry);
        y2.push(ShipwreckCount);
 });

 let trace2 = {
   x: x2,
   y: y2,
   type: 'bar'
 }
 let layout2 = {
   yaxis: {title: 'Shipwreck Count'},
 }
Plotly.plot(document.getElementById('graph2'), [trace2], layout2); });



// ------------- Plot 3 -------------------------------------------------------------------------------
let x3 = []
let y3_1 = []
let y3_2 = []
Plotly.d3.json('analyze_data/analyzeData_3.php', function(data){
 //console.log(data);
 data.forEach(function(d) {
        const MastNumber = parseInt(d.MastNumber);
        const DeckNumber = parseInt(d.DeckNumber);
        x3.push(d.Site);
        y3_1.push(MastNumber);
        y3_2.push(DeckNumber);
 });
 let trace3_1 = {
   x: x3,
   y: y3_1,
   type: 'bar',
   name: 'No. of Masts'
 }
 let trace3_2 = {
   x: x3,
   y: y3_2,
   type: 'bar',
   name: 'No. of Decks'
 }
 let layout3 = {
 }
  Plotly.plot(document.getElementById('graph3'), [trace3_1, trace3_2], layout3);
 });

</script>
</body>
</html>
