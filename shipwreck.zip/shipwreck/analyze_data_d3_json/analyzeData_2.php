<?php
    $username = "rakeshcg"; 
    $password = "1ga07ec079";   
    $host = "localhost";
    $database="shipwrecks";
    
    $server = mysql_connect($host, $username, $password);
    $connection = mysql_select_db($database, $server);

    $myquery = "SELECT `LostCountry` as 'LostCountry',count(*) as 'ShipwreckCount' FROM `ModernPMS` where `LostCountry` <> '' group by  `LostCountry`;";

    $query = mysql_query($myquery);
    
    if ( ! $query ) {
        echo mysql_error();
        die;
    }
    
    $data = array();
    
    for ($x = 0; $x < mysql_num_rows($query); $x++) {
        $data[] = mysql_fetch_assoc($query);
    }
    
    echo json_encode($data);     
     
    mysql_close($server);
?>