<?php
    $username = "rakeshcg"; 
    $password = "1ga07ec079";   
    $host = "localhost";
    $database="shipwrecks";
    
    $server = mysql_connect($host, $username, $password);
    $connection = mysql_select_db($database, $server);

    $myquery = "SELECT `Site`, `No. Masts` as 'MastNumber', `No. Decks` as 'DeckNumber' FROM `ModernPMS` WHERE `No. Masts`> 0 && `No. Decks` > 0";

    $query = mysql_query($myquery);
    
    if ( ! $query ) {
        echo mysql_error();
        die;
    }
    
    $data = array();
    
    for ($x = 0; $x < mysql_num_rows($query); $x++) {
        $data[] = mysql_fetch_assoc($query);
    }
    
    echo json_encode($data);     
     
    mysql_close($server);
?>